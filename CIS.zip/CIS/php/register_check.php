<?php
include('conn.php');

if (!isset($_POST['submit'])){
    exit('Unauthorized Login');
}
$username = $_POST['username'];
$password = $_POST['password'];
$pwd  = $_POST['pwd'];

//写入数据到数据库

if(strlen($password)<6){
    exit('Error: The lengther has to over 6 <a href = "javascript:history.back(-1);" >Try again </a>');
}
if($password == $pwd ){
    $che = mysqli_query($conn,'SELECT COUNT (*) from test where username = $username');
    if(mysqli_num_rows($che)==0){
        echo 'Wrong username', $username, 'already exist <a href = "javascript:history.back(-1);">Try again </a>';
        exit;
    }
$password = md5($password);
$pwd = md5($pwd);
$sql = "INSERT INTO register(username,password,pwd)VALUES('$username,$password,$pwd')";
$res = mysql_query($sql, $conn);
if($res){
    exit('Register Successful ! Click Here <a href="login_check.php">Login</a>');
}else{
    echo 'Sorry, register failed.', mysql_error(),'<br>'; 
    echo 'click here to try again <a href = javascript:history.back(-1);">Try again </a>';
}

}else{
    echo 'Password does not match';
    echo 'click here to try again <a href = "javascript:history.back(-1);">Try again </a>';
}
 

?>