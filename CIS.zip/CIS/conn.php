<?php
    $conn = mysqli_connect("localhost", "root", "", "test");
    if(!$conn){
        die("Disconnection Failed".mysql_error());   
    }
    //set datebase
    //mysqli_select_db($conn, "test");
    //字符设置
    ?>