<?php
include('conn.php');

if (!isset($_POST['submit'])){
    exit('Unauthorized Login');
}
$username = $_POST['username'];
$password = $_POST['password'];
$pwd  = $_POST['pwd'];

//写入数据到数据库

if(strlen($password)<6){
    exit('Error: The lengther has to over 6 <a href = "javascript:history.back(-1);" >Try again </a>');
}
if($password == $pwd ){
    $sql = "SELECT COUNT(*) FROM register WHERE username = '$username'";
    $che = mysqli_query($conn, $sql);
    $num = mysqli_fetch_row($che);
    if($num[0] == 0)
    {
        $password = md5($password);
        $sql = "INSERT INTO register (username,password) VALUES ('$username', '$password')";
        $res = mysqli_query($conn, $sql);
        if($res){
            exit('Register Successful ! Click Here <a href="login_check.php">Login</a>');
        }else{
            echo 'Sorry, register failed.' . mysqli_error($conn) . '<br>'; 
            echo 'click here to try again <a href = javascript:history.back(-1);">Try again </a>';
        }
    }
    else 
    {
        echo 'Wrong username ', $username, ' already exist <a href = "javascript:history.back(-1);">Try again </a>';
        exit;
    }
}
else
{
    echo 'Password does not match';
    echo 'click here to try again <a href = "javascript:history.back(-1);">Try again </a>';
}
 

?>